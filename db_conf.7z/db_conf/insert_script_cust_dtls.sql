INSERT INTO public.cust_dtls(
	cust_id, name, fname, mname, lname, dob, mobileno, occupation, city, state, addresspin, aadharno, panno, isekycdone, passportno, accountno)
	VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);